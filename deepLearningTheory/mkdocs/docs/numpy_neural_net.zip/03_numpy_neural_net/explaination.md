# Explaination

![Network architecture](./supporting_visualizations/nn_architecture.png)

Number of training samples: 900

X: (2)
y: (1)

RNN architecture:

{'input_dim': 2, 'output_dim': 25, 'activation': 'relu'}
{'input_dim': 25, 'output_dim': 50, 'activation': 'relu'}
{'input_dim': 50, 'output_dim': 50, 'activation': 'relu'}
{'input_dim': 50, 'output_dim': 25, 'activation': 'relu'}
{'input_dim': 25, 'output_dim': 1, 'activation': 'sigmoid'}

## Weights

Weights are spread accross 5 weights matrices: $W^{[1]}, W^{[2]}, W^{[3]}, W^{[4]}, W^{[5]}$

Each matrix has has shape: $W^{[l]}=(Input\_dimension, Output\_dimension)$

Then the shape of:

$W^{[1]}=(2,25)$
$W^{[2]}=(25,50)$
$W^{[3]}=(50,50)$
$W^{[4]}=(50,25)$
$W^{[5]}=(25,1)$

## Gradients

**J** is the cost function

We want $\frac{\partial J}{\partial W}$

To do so we separate by weights:

$\displaystyle \frac{\partial J}{\partial W^{[1]}}, \frac{\partial J}{\partial W^{[2]}},\frac{\partial J}{\partial W^{[3]}},\frac{\partial J}{\partial W^{[4]}},\frac{\partial J}{\partial W^{[5]}}$

We must ave as many gradients as weights so the shape of :

$\displaystyle W^{[1]}=\frac{\partial J}{\partial W^{[1]}}=(2,25)$

$\displaystyle W^{[2]}=\frac{\partial J}{\partial W^{[1]}}=(25,50)$

$\displaystyle W^{[3]}=\frac{\partial J}{\partial W^{[1]}}=(50,50)$

$\displaystyle W^{[4]}=\frac{\partial J}{\partial W^{[1]}}=(50,25)$

$\displaystyle W^{[5]}=\frac{\partial J}{\partial W^{[1]}}=(25,1)$

## Cost and loss

### Loss binary entropy

|  Important  |  Logistic loss function  |
|-------------|--------------------------|
| Loss | $\displaystyle \mathcal{L}(\hat{y},y)=-(y\log{\hat{y}}+(1-y)\log{(1-\hat{y})})$ |
| Can also be written as: | $\displaystyle \mathcal{L}(\hat{y}^{(i)}, y^{(i)}) =  - y^{(i)}  \log(\hat{y}^{(i)}) - (1-y^{(i)} )  \log(1-\hat{y}^{(i)})$ |

### Cost binary entropy

|  Important  |  Logistic loss function  |
|-------------|--------------------------|
| Cost | $\displaystyle J = \frac{1}{m} \sum_{i=1}^m \mathcal{L}(a^{(i)}, y^{(i)})$ |
| can also be written as | $J(w,b)= \frac{1}{m}\times{\sum_{i=1}^{m}-y^{(i)}\log{\hat{y}^{(i)}}-(1-y^{(i)})\log{(1-\hat{y}^{(i)})}}$ |
| Or: | $\displaystyle J(w,b)= - \frac{1}{m}\times{\sum_{i=1}^{m}y^{(i)}\log{\hat{y}^{(i)}}+(1-y^{(i)})\log{(1-\hat{y}^{(i)})}}$ |

### Derivative cost

$\displaystyle \frac{dJ}{d\hat y^{(i)}} = -1(\frac{y^{(i)}}{\hat y^{(i)}} - \frac{1-y^{(i)}}{1 - \hat y^{(i)}})$

Chain rule:
$\displaystyle {\frac {dz}{dx}}={\frac {dz}{dy}}\cdot {\frac {dy}{dx}}$

## Let's calculate

Notation:

$Y^{(i)}$ Denote the $i^{th}$ training example.

$\displaystyle J=\frac{1}{m}\times{\sum_{i=1}^{m}\mathcal{l}(\hat{y}^{(i)},y^{(i)})=\frac{1}{m}\times{\sum_{i=1}^{m}-[y^{(i)}\log{(a^{(i)})}+(1-y^{(i)})\log{(1-a^{(i)})}]}}$

### First let's work on $\frac{\partial J}{\partial W^{[5]}}$

$\displaystyle \frac{\partial J}{\partial W^{[5]}} = \frac{\partial J}{\partial W^{[5]}}$

----

Calculation of the derivative of the cost function
$\displaystyle \frac{dJ}{d\hat y^{(i)}}  = -(\frac{y^{(i)}}{\hat y^{(i)}} - \frac{1-y^{(i)}}{1 - \hat y^{(i)}})$

Calculation of the derivative of the activation function (SIGMOID or RELU)
$dZ = dA * sigmoid(Z) * (1 - sigmoid(Z))$

Calculation of the derivative of the matrix W
$dW =  \frac{1}{m} dZ . A\_prev$

```python

dA_prev = - (np.divide(Y, Y_hat) - np.divide(1 - Y, 1 - Y_hat))
    
for layer_idx_prev, layer_nn_architecture in reversed(list(enumerate(nn_architecture))):

    dA_curr = dA_prev

    dZ_curr = backward_activation_func(dA_curr, Z_curr)
    
    # derivative of the matrix W
    dW_curr = np.dot(dZ_curr, A_prev.T) / m

    # derivative of the vector b
    db_curr = np.sum(dZ_curr, axis=1, keepdims=True) / m
    
    # derivative of the matrix A_prev
    dA_prev = np.dot(W_curr.T, dZ_curr)

# update

for layer_idx, layer in enumerate(nn_architecture, 1):
    params_values["W" + str(layer_idx)] -= learning_rate * grads_values["dW" + str(layer_idx)]        
    params_values["b" + str(layer_idx)] -= learning_rate * grads_values["db" + str(layer_idx)]

```